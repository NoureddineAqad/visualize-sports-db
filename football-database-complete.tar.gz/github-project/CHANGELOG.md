# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2025-11-27

### 🎯 Major Feature: Intelligent Fuzzy Team Name Matching

#### Added
- **Fuzzy team name matching algorithm** in `football_db.py`
  - `normalize_team_name()` method for cleaning team names
  - `find_team_fuzzy()` method for intelligent name matching
  - Integrated into both calendar entry and results entry workflows

#### Features
- ✨ Handles special characters: "Bodo/Glimt" → finds "BodoGlimt"
- ✨ Case-insensitive matching: "bodoglimt" → finds "BodoGlimt"
- ✨ Partial name matching: "Man City" → finds "Manchester City"
- ✨ Visual feedback: Shows "→ Matched: TeamName" when fuzzy match occurs
- ✨ Fallback suggestions: Shows similar teams if no match found

#### Fixed
- 🐛 **Critical**: Fixed "Team not found" error when team names contain special characters
- 🐛 **Critical**: Fixed mismatch between fixture team names and database team names
- 🐛 Fixed results entry failing when old fixtures used different team name format
- 🐛 Fixed KeyError when updating team statistics with mismatched names

#### Changed
- 📝 Updated `enter_matchday_calendar()` to use fuzzy matching for home/away team input
- 📝 Updated `enter_matchday_results()` to use fuzzy matching for team verification
- 📝 Improved error messages to be more helpful
- 📝 Enhanced user feedback during team selection

#### Technical Details
```python
# New methods in FootballDatabase class:
def normalize_team_name(self, name: str) -> str
def find_team_fuzzy(self, search_name: str) -> Optional[str]

# Modified methods:
def enter_matchday_calendar(self, matchday: int)  # Lines 274-311, 313-357
def enter_matchday_results(self, matchday: int)   # Lines 408-426
```

### Documentation
- Updated README.md with fuzzy matching feature description
- Added fuzzy matching examples and usage guide
- Updated troubleshooting section
- Added "The Fuzzy Matching Feature" section

---

## [1.0.0] - 2025-11-15

### Initial Release

#### Added
- 📊 Core database management system
  - Team management (add, edit, delete)
  - Match scheduling and results
  - Automatic standings calculation
  - UEFA-style ranking criteria

- 🌐 Web scraping functionality
  - Fetch Champions League teams automatically
  - Scrape match results from web sources
  - User verification for scraped data

- 🎲 Monte Carlo simulation
  - Tournament outcome predictions
  - Qualification probability calculations
  - Statistical analysis

- 💾 Data persistence
  - JSON file storage
  - Save/load competitions
  - Export standings to text files

- 🖥️ User interfaces
  - CLI menu system
  - GUI dashboard (optional)
  - Interactive prompts

#### Features
- Two-step workflow: Calendar entry → Results entry
- Team number selection (1-36) or name entry
- Matchday-by-matchday result entry
- Real-time standings updates
- Match history viewing
- Competition state management

#### Technical
- Python 3.8+ support
- Modular architecture
- Type hints for better code clarity
- Error handling and validation
- Extensible design

---

## Version Comparison

| Feature | v1.0.0 | v1.1.0 |
|---------|--------|--------|
| Basic database | ✅ | ✅ |
| Web scraping | ✅ | ✅ |
| Monte Carlo | ✅ | ✅ |
| GUI dashboard | ✅ | ✅ |
| **Fuzzy matching** | ❌ | ✅ NEW! |
| **Special char handling** | ❌ | ✅ NEW! |
| **Smart team lookup** | ❌ | ✅ NEW! |

---

## Upgrade Guide

### From v1.0.0 to v1.1.0

#### What Changed
- Added fuzzy matching capability
- No breaking changes to existing functionality
- Backward compatible with v1.0.0 databases

#### Steps to Upgrade
```bash
# 1. Backup your current files
cp football_db.py football_db_v1.0.0_backup.py

# 2. Pull latest changes
git pull origin main

# 3. Your existing data files work without modification
# No migration needed!
```

#### New Capabilities
- You can now type team names with special characters
- Old fixtures with different team name formats will still work
- More forgiving team name input

#### Compatibility
- ✅ JSON files from v1.0.0 work in v1.1.0
- ✅ All v1.0.0 features preserved
- ✅ No breaking API changes
- ✅ Existing scripts continue to work

---

## Breaking Changes

### v1.1.0
- None

### v1.0.0
- Initial release (no breaking changes)

---

## Deprecation Warnings

### v1.1.0
- None

---

## Known Issues

### v1.1.0
- GUI dashboard requires additional dependencies (matplotlib, customtkinter)
- Web scraping may fail if website structure changes
- Monte Carlo simulation can be slow with many simulations (>100k)

### v1.0.0
- Team names with special characters caused errors (FIXED in v1.1.0 ✅)
- Mismatch between fixture and database team names (FIXED in v1.1.0 ✅)

---

## Contributors

- **[Your Name]** - Initial work and v1.0.0
- **[Your Name]** - Fuzzy matching feature (v1.1.0)
- [Contributors welcome!]

---

## Links

- [Repository](https://github.com/yourusername/football-database)
- [Issues](https://github.com/yourusername/football-database/issues)
- [Releases](https://github.com/yourusername/football-database/releases)

---

**Note**: For detailed commit history, see the [Git log](https://github.com/yourusername/football-database/commits/main).
