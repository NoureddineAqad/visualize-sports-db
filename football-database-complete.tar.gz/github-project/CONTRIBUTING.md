# Contributing to Champions League Database

First off, thank you for considering contributing to this project! It's people like you that make this tool better for everyone.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [How Can I Contribute?](#how-can-i-contribute)
- [Style Guidelines](#style-guidelines)
- [Commit Messages](#commit-messages)
- [Pull Request Process](#pull-request-process)

## Code of Conduct

This project adheres to a simple code of conduct:

- Be respectful and inclusive
- Provide constructive feedback
- Focus on what's best for the project
- Show empathy towards other contributors

## Getting Started

1. **Fork the repository** on GitHub
2. **Clone your fork** locally:
   ```bash
   git clone https://github.com/YOUR_USERNAME/champions-league-db.git
   cd champions-league-db
   ```
3. **Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
4. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
5. **Create a branch** for your changes:
   ```bash
   git checkout -b feature/your-feature-name
   ```

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates.

When creating a bug report, include:

- **Clear title**: Describe the issue briefly
- **Description**: Explain what happened and what you expected
- **Steps to reproduce**: List the steps to reproduce the bug
- **Environment**: OS, Python version, package versions
- **Screenshots**: If applicable
- **Error messages**: Full error traceback

Example:

```markdown
**Title**: Animation freezes on large datasets

**Description**: When loading a database with more than 50 teams, 
the racing bars animation freezes after 10 seconds.

**Steps to Reproduce**:
1. Load database with 50+ teams
2. Click "Generate Racing Bars"
3. Select "Fast" speed
4. Animation starts but freezes at matchday 3

**Environment**:
- OS: Windows 11
- Python: 3.11.0
- matplotlib: 3.8.0

**Error Message**:
```
MemoryError: Unable to allocate array
```
```

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, include:

- **Clear title**: Describe the enhancement
- **Use case**: Explain why this would be useful
- **Implementation**: Suggest how it might be implemented (optional)
- **Alternatives**: Mention alternative solutions you've considered

Example:

```markdown
**Title**: Add export to Excel feature

**Use Case**: Users want to export standings to Excel for further 
analysis and reporting.

**Implementation**: Add "Export to Excel" button that uses pandas 
to create an .xlsx file with formatted standings.

**Alternatives**: 
- Export to CSV (simpler but less formatted)
- Export to PDF (for sharing/printing)
```

### Code Contributions

Areas where contributions are welcome:

1. **Bug Fixes**: Fix reported bugs
2. **Features**: Implement new features from issues
3. **Documentation**: Improve README, tutorials, code comments
4. **Tests**: Add unit tests for existing code
5. **Performance**: Optimize slow operations
6. **UI/UX**: Improve GUI design and usability

## Style Guidelines

### Python Code Style

Follow PEP 8 guidelines:

```python
# Good
def calculate_standings(teams, sort_by="points"):
    """
    Calculate team standings based on criteria.
    
    Args:
        teams: List of Team objects
        sort_by: Sorting criteria (default: "points")
    
    Returns:
        List of teams sorted by standings
    """
    return sorted(teams, key=lambda t: -getattr(t, sort_by))


# Bad
def calc_stand(t,s="points"):
    return sorted(t,key=lambda x:-getattr(x,s))
```

### Key Points

- **Indentation**: 4 spaces (no tabs)
- **Line length**: Maximum 88 characters (Black formatter default)
- **Naming**:
  - Functions/variables: `snake_case`
  - Classes: `PascalCase`
  - Constants: `UPPER_SNAKE_CASE`
- **Docstrings**: Use for all public functions/classes
- **Type hints**: Use when it improves clarity
- **Comments**: Explain why, not what

### Documentation Style

- Use Markdown for all documentation
- Keep line length reasonable (80-100 chars)
- Use code blocks with language specification
- Include examples where helpful

## Commit Messages

Write clear, descriptive commit messages:

### Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

- **feat**: New feature
- **fix**: Bug fix
- **docs**: Documentation changes
- **style**: Code style changes (formatting, no logic change)
- **refactor**: Code refactoring
- **test**: Adding/updating tests
- **chore**: Maintenance tasks

### Examples

Good commit messages:

```
feat(animation): add customizable frame rate

Allow users to set custom FPS for animations via settings.
Defaults to 30 FPS for compatibility.

Closes #123
```

```
fix(database): resolve team lookup KeyError

Teams were accessed by list index instead of dictionary key.
Added helper functions to work with both formats.

Fixes #45
```

Bad commit messages:

```
fixed bug
```

```
updated files
```

```
changes
```

## Pull Request Process

1. **Update documentation**: Ensure README/tutorials reflect your changes
2. **Add tests**: Include tests for new features
3. **Check style**: Run linters/formatters:
   ```bash
   flake8 .
   black .
   ```
4. **Test thoroughly**: Ensure all tests pass:
   ```bash
   python -m pytest tests/
   ```
5. **Update CHANGELOG**: Add entry for your changes
6. **Create pull request** with:
   - Clear title describing the change
   - Reference to related issue(s)
   - Description of what changed and why
   - Screenshots (if UI changes)
   - Testing performed

### Pull Request Template

```markdown
## Description
Brief description of changes

## Related Issue
Fixes #(issue number)

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Performance improvement

## Testing
- [ ] Tested locally
- [ ] Added unit tests
- [ ] All tests pass

## Screenshots (if applicable)
Add screenshots here

## Checklist
- [ ] Code follows style guidelines
- [ ] Documentation updated
- [ ] Tests added/updated
- [ ] CHANGELOG updated
```

## Development Workflow

### Setting Up Development Environment

```bash
# Clone your fork
git clone https://github.com/YOUR_USERNAME/champions-league-db.git
cd champions-league-db

# Add upstream remote
git remote add upstream https://github.com/ORIGINAL_OWNER/champions-league-db.git

# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install dependencies including dev tools
pip install -r requirements.txt
pip install pytest flake8 black mypy

# Run tests
python -m pytest tests/

# Check code style
flake8 .
black --check .
```

### Before Submitting

```bash
# Update your fork
git checkout main
git pull upstream main
git push origin main

# Rebase your feature branch
git checkout feature/your-feature
git rebase main

# Run tests
python -m pytest tests/

# Check style
flake8 .
black .

# Commit and push
git add .
git commit -m "feat: your feature description"
git push origin feature/your-feature
```

## Questions?

Feel free to:

- Open an issue with your question
- Start a discussion on GitHub
- Reach out to maintainers

## Recognition

Contributors will be:

- Listed in CONTRIBUTORS.md
- Mentioned in release notes
- Thanked in the community

Thank you for contributing! 🎉
